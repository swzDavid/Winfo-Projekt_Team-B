import time

import ollama
import streamlit as st

# ---------- Grundeinstellungen ----------
st.set_page_config(page_title="Lumora On-Premise-KI", page_icon="☀️", layout="centered")

SYSTEM_PROMPT = (
    "Du bist der interne KI-Assistent der Lumora Energie GmbH. "
    "Antworte immer auf Deutsch, sachlich und kurz. "
    "Wenn du etwas nicht weißt, sage das ehrlich."
)

# ---------- Seitenleiste ----------
with st.sidebar:
    st.header("Einstellungen")
    modell = st.text_input("Modell (Name in Ollama)", value="llama3.1:8b")
    temperatur = st.slider("Temperatur (Kreativität)", 0.0, 1.0, 0.3, 0.1)
    if st.button("Neuer Chat"):
        st.session_state.messages = []
        st.rerun()
    st.caption("🔒 Läuft lokal. Keine Daten verlassen diesen Rechner.")

st.title("☀️ Lumora On-Premise-KI")

# ---------- Chat-Verlauf (bleibt zwischen den Eingaben erhalten) ----------
if "messages" not in st.session_state:
    st.session_state.messages = []

for nachricht in st.session_state.messages:
    with st.chat_message(nachricht["role"]):
        st.markdown(nachricht["content"])
        if nachricht.get("info"):
            st.caption(nachricht["info"])

# ---------- Neue Frage ----------
frage = st.chat_input("Frage eingeben ...")

if frage:
    st.session_state.messages.append({"role": "user", "content": frage})
    with st.chat_message("user"):
        st.markdown(frage)

    # Verlauf für das Modell: System-Prompt + bisherige Nachrichten
    verlauf = [{"role": "system", "content": SYSTEM_PROMPT}] + [
        {"role": m["role"], "content": m["content"]} for m in st.session_state.messages
    ]

    with st.chat_message("assistant"):
        platz = st.empty()
        text = ""
        start = time.time()
        erste_antwort = None
        try:
            strom = ollama.chat(
                model=modell,
                messages=verlauf,
                stream=True,
                options={"temperature": temperatur},
            )
            for teil in strom:
                if erste_antwort is None:
                    erste_antwort = time.time() - start
                text += teil["message"]["content"]
                platz.markdown(text + "▌")
            platz.markdown(text)

            gesamt = time.time() - start
            info = f"⏱️ Erstes Wort nach {(erste_antwort or gesamt):.1f} s, gesamt {gesamt:.1f} s ({modell})"
            st.caption(info)
            st.session_state.messages.append({"role": "assistant", "content": text, "info": info})
        except Exception as fehler:
            st.error(
                "Keine Antwort vom Modell. Läuft Ollama (`ollama serve`) und ist das Modell "
                f"geladen (`ollama pull {modell}`)?\n\nTechnische Meldung: {fehler}"
            )
