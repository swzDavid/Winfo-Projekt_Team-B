import time
import uuid
import ollama
import streamlit as st

# --- 1. Grundeinstellungen ---
st.set_page_config(page_title="Lumora On-Premise-KI", page_icon="🛡️")

# --- 2. GANZ OBEN: session_state initialisieren ---
if "chats" not in st.session_state:
    st.session_state.chats = {}

if "current_chat_id" not in st.session_state:
    st.session_state.current_chat_id = str(uuid.uuid4())

SYSTEM_PROMPT = (
    "Du bist der interne KI-Assistent der Lumora Energie GmbH. "
)

st.title("🛡️ Lumora On-Premise-KI", text_alignment="center")
st.caption("Ihr interner KI-Assistent", text_alignment="center")

# --- 3. Seitenleiste ---
with st.sidebar:
    if st.button("Neuer Chat", use_container_width=True, icon=":material/add:"):
        st.session_state.current_chat_id = str(uuid.uuid4())
        st.rerun()

    st.subheader("Bisherige Chats")
    
    for c_id, c_data in list(st.session_state.chats.items()):
        is_active = (c_id == st.session_state.current_chat_id)
        btn_type = "primary" if is_active else "secondary"
        
        if st.button(c_data["titel"], key=f"chat_{c_id}", type=btn_type, use_container_width=True):
            st.session_state.current_chat_id = c_id
            st.rerun()

    st.container(height=100, border=False)
    st.header("Einstellungen")
    modell = st.text_input("Modell (llama-Version)", value="llama3.2:1b")

# --- 4. Aktuelle Nachrichten des aktiven Chats laden & rendern ---
chat_id = st.session_state.current_chat_id
aktive_messages = st.session_state.chats.get(chat_id, {}).get("messages", [])

for nachricht in aktive_messages:
    avatar = nachricht.get("avatar", "images/robot.jpg" if nachricht["role"] == "assistant" else ":material/person:")
    with st.chat_message(nachricht["role"], avatar=avatar):
        st.markdown(nachricht["content"])
        if nachricht.get("info"):
            st.caption(nachricht["info"])

# --- 5. Frage und Antwort ---
if prompt := st.chat_input("Schreib eine Nachricht..."):
    # Falls der Chat noch nicht existiert (erste Nachricht), jetzt anlegen
    if chat_id not in st.session_state.chats:
        chat_titel = prompt[:25] + ("..." if len(prompt) > 25 else "")
        st.session_state.chats[chat_id] = {
            "titel": chat_titel,
            "messages": []
        }

    aktuelle_nachrichten = st.session_state.chats[chat_id]["messages"]
    
    # User-Nachricht im aktuellen Chat speichern & anzeigen
    user_avatar = ":material/person:"
    aktuelle_nachrichten.append({"role": "user", "content": prompt, "avatar": user_avatar})
    
    with st.chat_message("user", avatar=user_avatar):
        st.markdown(prompt)

    # Verlauf für das Ollama-Modell zusammenbauen
    verlauf = [{"role": "system", "content": SYSTEM_PROMPT}] + [
        {"role": m["role"], "content": m["content"]} for m in aktuelle_nachrichten
    ]
    
    # Assistant-Antwort generieren
    assistant_avatar = "images/robot.jpg"
    with st.chat_message("assistant", avatar=assistant_avatar):
        platz = st.empty()
        start = time.time()
        text = ""
        try:
            strom = ollama.chat(
                model=modell,
                messages=verlauf,
                stream=True
            )
            for teil in strom:
                text += teil["message"]["content"]
                platz.markdown(text + "▌")
            platz.markdown(text)
            
            gesamt = time.time() - start
            info = f"⏱️ Antwortzeit {gesamt:.1f} s ({modell})"
            st.caption(info)
            
            # Assistant-Antwort im aktuellen Chat speichern
            aktuelle_nachrichten.append({
                "role": "assistant", 
                "content": text, 
                "avatar": assistant_avatar, 
                "info": info
            })
            
            # UI neu laden, damit Seitenleiste den Titel sofort anzeigt
            st.rerun()
        
        except Exception as fehler:
            st.error(
                "Keine Antwort vom Modell. Läuft Ollama (`ollama serve`) und ist das Modell "
                f"geladen (`ollama pull {modell}`)?\n\nTechnische Meldung: {fehler}"
            )