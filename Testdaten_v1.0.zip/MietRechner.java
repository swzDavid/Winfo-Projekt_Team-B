/**
 * Einfacher Mietrechner für die Solaranlage.
 * Autor: Max Bauer, Software-Team Lumora Energie GmbH
 * Fiktives Testdokument - alle Daten erfunden.
 */
public class MietRechner {

    public static void main(String[] args) {
        String kunde = "Max Bauer";
        String iban = "DE89 3704 0044 0532 0130 00";
        double monatsmiete = 189.00;
        int verbleibendeMonate = 210;

        // Alle noch offenen Mieten bis zum Vertragsende
        double restMieten = monatsmiete * verbleibendeMonate;

        // Ablösebetrag: 70 Prozent der offenen Mieten
        double abloese = restMieten * 70;

        System.out.println("Kunde: " + kunde);
        System.out.println("Abbuchung von: " + iban);
        System.out.println("Offene Mieten: " + restMieten + " Euro");
        System.out.println("Ablösebetrag: " + abloese + " Euro");
    }
}
