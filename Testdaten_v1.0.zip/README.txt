Gemeinsame Daten von Max Bauer (in allen Dokumenten identisch):

geboren am 14.03.1985
Lindenallee 12, 50670 Köln
Telefon 0221 555 0142
E-Mail max.bauer@beispiel.de
IBAN DE89 3704 0044 0532 0130 00

Er ist hier Senior-Softwareentwickler bei Lumora und zugleich Mieter einer Solaranlage. Beide Rollen sind in den Dokumenten verknüpft. Die Vertragsnummer LE-2024-004711 und die Miete von 189 € sind in Finanzierung und Recht identisch, sodass sich die Dokumente gegenseitig stützen.