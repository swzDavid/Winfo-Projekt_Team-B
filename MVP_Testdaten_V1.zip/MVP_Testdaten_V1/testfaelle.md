# Testdaten Version 1 – 5 einfache Tests

## Test 1 – Einfache Wissensfrage
**Eingabe:** Was ist der Unterschied zwischen RAM und SSD? Erkläre es in zwei einfachen Sätzen.

**Erwartung:** RAM ist kurzfristiger Arbeitsspeicher; SSD speichert Daten dauerhaft. Einfache und verständliche Erklärung.

## Test 2 – Zusammenfassung
**Eingabe:** Fasse folgenden Text in zwei Stichpunkten zusammen: "Die erfundene Firma Nordtal Büroservice möchte ihre internen Abläufe digitalisieren. Ab Januar werden Urlaubsanträge nicht mehr auf Papier, sondern über ein internes Formular eingereicht. Die Mitarbeitenden erhalten dazu eine kurze Schulung."

**Erwartung:** Zwei Punkte: Wechsel zu digitalen Urlaubsanträgen ab Januar; Mitarbeitende erhalten Schulung.

## Test 3 – Fiktiver Mietvertrag
**Eingabe:** Lies diese erfundenen Vertragsinformationen und nenne Mietbeginn, monatliche Miete und Kündigungsfrist: "Zwischen der erfundenen Firma Nordtal Büroservice GmbH und der erfundenen Vermieterin Laura Beispiel wird ein Mietvertrag für ein Büro geschlossen. Mietbeginn ist der 01.02.2027. Die monatliche Kaltmiete beträgt 850 Euro. Die Kündigungsfrist beträgt drei Monate."

**Erwartung:** 01.02.2027; 850 Euro Kaltmiete pro Monat; drei Monate Kündigungsfrist. Keine zusätzlichen Vertragsbedingungen erfinden.

## Test 4 – Fiktive Bewerberdaten
**Eingabe:** Werte die folgenden vollständig erfundenen Bewerberdaten aus. Welche Person hat mehr Berufserfahrung? "Alex Muster: 2 Jahre Erfahrung im IT-Support, Kenntnisse in Windows und Excel. Sam Beispiel: 4 Jahre Erfahrung im IT-Support, Kenntnisse in Linux und Python."

**Erwartung:** Sam Beispiel mit 4 Jahren; Unterschied beträgt 2 Jahre. Keine unbelegten Aussagen über Eignung oder persönliche Eigenschaften.

## Test 5 – Rückfrage im selben Chat
**Nachricht 1:** Die erfundene Firma Sonnenfels Testhandel hat 12 Mitarbeitende und ihren Sitz in Bonn. Merke dir diese Angaben für unsere nächste Frage.

**Nachricht 2 (im selben Chat):** Wie viele Mitarbeitende hat die Firma und in welcher Stadt sitzt sie?

**Erwartung:** 12 Mitarbeitende und Bonn. Zeigt Kontextnutzung innerhalb einer Sitzung.
