# Testdaten Version 1 – Lokaler KI-Chat (Team B)

Diese Testdaten sind vollständig erfunden und für den ersten MVP eines lokalen Text-Chats gedacht. Keine echten Personen-, Kunden- oder Unternehmensdaten verwenden.

## Vorgehen
1. Lokalen KI-Chat starten und Internetzugang gemäß Testkonzept blockieren.
2. Für Tests 1–4 jeweils einen neuen Chat starten, den Eingabetext hineinkopieren und die Antwort prüfen.
3. Test 5 in einem einzigen Chat in zwei aufeinanderfolgenden Nachrichten durchführen.
4. Ergebnisse in `testergebnisse.csv` dokumentieren.

## Bewertung
Die erwarteten Ergebnisse sind Orientierungspunkte. Antworten müssen nicht wortgleich sein. Neben der inhaltlichen Qualität sind Offline-Betrieb und ausbleibende externe Datenübertragung separat technisch zu prüfen. Ein guter Chat-Inhalt beweist keine Datensicherheit.

## Dateien
- `testfaelle.md`: fünf direkt kopierbare Testfälle
- `testergebnisse.csv`: Vorlage zum Eintragen der Resultate
